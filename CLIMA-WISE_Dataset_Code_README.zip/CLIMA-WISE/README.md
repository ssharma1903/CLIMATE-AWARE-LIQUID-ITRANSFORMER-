# CLIMA-WISE

Climate-aware Liquid iTransformer for Irrigation Demand Forecasting.

Dataset: USGS Irrigation Water Use Reanalysis Dataset (2000-2020).

## Structure
- data/raw : original dataset
- src : preprocessing and forecasting code
- outputs : prediction results

## Run
python src/train.py
python src/predict.py
