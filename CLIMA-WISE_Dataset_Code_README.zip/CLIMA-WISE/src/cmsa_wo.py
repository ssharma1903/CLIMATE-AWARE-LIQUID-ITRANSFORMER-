import numpy as np

def select_features(X):
    idx=np.argsort(np.var(X,axis=0))[-8:]
    return X[:,idx],idx
