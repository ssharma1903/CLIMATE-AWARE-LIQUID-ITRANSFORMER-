import torch
import torch.nn as nn
class CLIMAWISE(nn.Module):
    def __init__(self,d):
        super().__init__();self.t=nn.TransformerEncoder(nn.TransformerEncoderLayer(d_model=d,nhead=2),1);self.f=nn.Linear(d,1)
    def forward(self,x):
        return self.f(self.t(x)[:,-1,:])
