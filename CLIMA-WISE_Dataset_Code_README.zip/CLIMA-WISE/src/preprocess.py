import pandas as pd
from sklearn.preprocessing import PowerTransformer
from sklearn.impute import KNNImputer

def preprocess(df):
    num=df.select_dtypes("number")
    df[num.columns]=KNNImputer().fit_transform(num)
    df[num.columns]=PowerTransformer(method="yeo-johnson").fit_transform(df[num.columns])
    return df
