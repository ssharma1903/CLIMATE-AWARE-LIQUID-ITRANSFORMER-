from PyEMD import CEEMDAN

def decompose(signal):
    return CEEMDAN()(signal)
